@echo off
setlocal
cd /d "%~dp0"

echo [1/4] Installing JavaScript dependencies...
npm install
if errorlevel 1 goto :fail

echo [2/4] Building web application...
npm run build:web
if errorlevel 1 goto :fail

echo [3/4] Creating Android project (first run only)...
if not exist android (
  npx cap add android
  if errorlevel 1 goto :fail
)

echo [4/4] Syncing Android project...
npx cap sync android
if errorlevel 1 goto :fail

echo.
echo DONE. Open Android Studio with: npm run android:open
exit /b 0
:fail
echo.
echo Setup failed. Check the error above.
exit /b 1
