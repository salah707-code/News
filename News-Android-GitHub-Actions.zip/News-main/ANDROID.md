# The Reporter — Android packaging

This repository is prepared to package the existing React/Vite application as an Android app with Capacitor 8.

## Important architecture note

The Android app contains the React UI, but the existing Express server (`server.ts`) is still required for live RSS parsing and Gemini summaries. A phone cannot use `/api/...` on the developer PC as if it were localhost.

For production Android, deploy the Node/Express backend over HTTPS and set:

`VITE_API_BASE_URL=https://YOUR-NEWS-BACKEND-DOMAIN`

before `npm run build:web` / `npm run android:sync`.

The browser build remains compatible with a same-origin `/api` when `VITE_API_BASE_URL` is empty.

## Requirements

- Node.js 22+
- Android Studio 2025.2.1 or newer for Capacitor 8
- Android SDK with API 24+ available

## First Android setup on Windows

1. Install Node.js 22+.
2. Install Android Studio and the required Android SDK.
3. Open this folder in a terminal.
4. Copy `.env.android.example` to `.env` and replace the API URL with your HTTPS backend.
5. Run `setup-android.bat`.
6. Run `npm run android:open`.
7. In Android Studio, let Gradle sync and select a device.
8. Build/debug the app.

## Manual commands

```bash
npm install
npm run build:web
npx cap add android
npx cap sync android
npx cap open android
```

## Production

Use an HTTPS backend. Do not put `GEMINI_API_KEY` in the Android app. It belongs on the Node/Express server.

## Package ID

`com.salah707.thereporter`

## App name

`The Reporter`
