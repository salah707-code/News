#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

echo '[1/4] Installing JavaScript dependencies...'
npm install

echo '[2/4] Building web application...'
npm run build:web

echo '[3/4] Creating Android project (first run only)...'
if [ ! -d android ]; then
  npx cap add android
fi

echo '[4/4] Syncing Android project...'
npx cap sync android

echo
 echo 'DONE. Open Android Studio with: npm run android:open'
