/**
 * API base URL for the Android build.
 *
 * Web development: leave VITE_API_BASE_URL empty and requests use /api.
 * Android production: set VITE_API_BASE_URL to the HTTPS URL of your News backend.
 */
export function apiUrl(path: string): string {
  const base = (import.meta.env.VITE_API_BASE_URL || '').replace(/\/$/, '');
  const normalized = path.startsWith('/') ? path : `/${path}`;
  return base ? `${base}${normalized}` : normalized;
}
