# بناء News على GitHub Actions

## تشغيل البناء

1. ارفع محتويات هذا المشروع إلى مستودع GitHub.
2. ادخل إلى تبويب **Actions**.
3. اختر **Android Build**.
4. اضغط **Run workflow**.
5. اختر الفرع `main` ثم اضغط **Run workflow**.
6. بعد انتهاء المهمة بنجاح افتح صفحة التشغيل.
7. في قسم **Artifacts** ستجد:
   - `News-debug-apk` — ملف APK للتجربة على الهاتف.
   - `News-release-aab-unsigned` — ملف AAB غير موقّع، يحتاج توقيعًا قبل نشره على Google Play.

## ملاحظات

- لا يحتاج هذا الـ workflow إلى Android Studio على جهازك.
- يتم إنشاء مجلد `android/` تلقائيًا داخل GitHub Runner بواسطة Capacitor.
- يتم استخدام Node.js 22 وJava 21.
- مفتاح Gemini لا ينبغي وضعه داخل التطبيق؛ يجب أن يبقى في الخادم.
- إذا كان التطبيق يعتمد على API مستضاف، اضبط عنوان الـ API في إعدادات المشروع/البيئة قبل الإنتاج.
