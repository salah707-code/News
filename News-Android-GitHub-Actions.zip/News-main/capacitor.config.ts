import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.salah707.thereporter',
  appName: 'The Reporter',
  webDir: 'dist',
  bundledWebRuntime: false,
  server: {
    // Optional: set VITE_CAPACITOR_SERVER_URL to a hosted web build during development.
    // Do NOT use this for production unless you intentionally want a remote web app.
    ...(process.env.VITE_CAPACITOR_SERVER_URL
      ? { url: process.env.VITE_CAPACITOR_SERVER_URL, cleartext: false }
      : {}),
  },
};

export default config;
